package edu.miu.cs.cs425.finalexam;
import edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.model.Patient;
import edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.service.impl.PatientServiceImpl;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class PatientsServiceImplTest {


    private PatientServiceImpl patientService;

    @Before
    public void setUp() {
        patientService= new PatientServiceImpl();
    }

    @Test
    public void getElderlyPatients(){


        List<Patient> expected_out = patientService.getElderlyPatients();
        List<Patient> actual_out=new ArrayList<>();

        actual_out.add(new Patient(1003, "Charles Babbage", LocalDate.of(1957, 4, 18)));


        assertEquals(expected_out.get(0).getFullName(),actual_out.get(0).getFullName());


    }
}
