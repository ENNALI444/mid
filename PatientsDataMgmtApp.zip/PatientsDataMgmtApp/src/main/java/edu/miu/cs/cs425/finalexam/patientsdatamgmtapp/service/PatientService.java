package edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.service;

import edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.model.Patient;

import java.util.List;

public interface PatientService {

    public abstract List<Patient> getAllPatients();
    public abstract List<Patient> getElderlyPatients();

}
