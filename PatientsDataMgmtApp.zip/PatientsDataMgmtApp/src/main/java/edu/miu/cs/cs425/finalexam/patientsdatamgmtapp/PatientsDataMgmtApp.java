package edu.miu.cs.cs425.finalexam.patientsdatamgmtapp;

import edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.service.impl.PatientServiceImpl;

public class PatientsDataMgmtApp {

    public static void main(String[] args) {
        System.out.println("Hello, CS425-SWE-FinalExam PatientsDataMgmtApp!!!");
        var patientsService = new PatientServiceImpl();
        //---- PRINT ALL PATIENTS -----//
        System.out.println("//---- PRINTING ALL PATIENTS -----//");
        patientsService.getAllPatients()
                .forEach(System.out::println);
        //---- PRINT ELDERLY PATIENTS ONLY -----//
        System.out.println("//---- PRINTING ELDERLY PATIENTS -----//");
        patientsService.getElderlyPatients()
                .forEach(System.out::println);
    }
}
