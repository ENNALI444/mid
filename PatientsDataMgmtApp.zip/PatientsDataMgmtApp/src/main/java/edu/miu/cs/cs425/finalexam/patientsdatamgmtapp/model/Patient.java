package edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.model;

import java.time.LocalDate;
import java.time.Period;
import java.util.StringJoiner;

public class Patient {
    private Integer patientId;
    private String fullName;
    private LocalDate dateOfBirth;
    private boolean elderly;

    public Patient(Integer patientId, String fullName, LocalDate dateOfBirth) {
        this.patientId = patientId;
        this.fullName = fullName;
        this.dateOfBirth = dateOfBirth;
    }

    public Integer getPatientId() {
        return patientId;
    }

    public void setPatientId(Integer patientId) {
        this.patientId = patientId;
    }

    public String getFullName() {
        return fullName;
    }

    public boolean isElderly() {
        //wrong
        //return (LocalDate.now().getYear() - this.dateOfBirth.getYear() >= 65);

        //Correct
        return Period.between(this.dateOfBirth, LocalDate.now()).getYears() >= 65;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Patient.class.getSimpleName() + "[", "]")
                .add("patientId=" + patientId)
                .add("fullName='" + fullName + "'")
                .add("dateOfBirth=" + dateOfBirth)
                .toString();
    }
}
