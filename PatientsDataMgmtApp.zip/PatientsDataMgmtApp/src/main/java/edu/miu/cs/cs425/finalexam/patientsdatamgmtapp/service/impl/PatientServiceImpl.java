package edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.service.impl;

import edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.datarepository.PatientsDataRepository;
import edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.model.Patient;
import edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.service.PatientService;

import java.util.ArrayList;
import java.util.List;

public class PatientServiceImpl implements PatientService {

    @Override
    public List<Patient> getAllPatients() {
        return PatientsDataRepository.findAll();
    }

    @Override
    public List<Patient> getElderlyPatients() {
        var elderlyPatients = new ArrayList<Patient>();
        for(var patient : PatientsDataRepository.findAll()) {
            if(patient.isElderly()) {
                elderlyPatients.add(patient);
            }
        }
        return elderlyPatients;
    }
}
