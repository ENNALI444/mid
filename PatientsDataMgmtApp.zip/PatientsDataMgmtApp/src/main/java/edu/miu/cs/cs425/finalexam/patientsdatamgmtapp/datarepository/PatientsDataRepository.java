package edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.datarepository;

import edu.miu.cs.cs425.finalexam.patientsdatamgmtapp.model.Patient;

import java.time.LocalDate;
import java.util.List;

public class PatientsDataRepository {

    private static final List<Patient> PATIENTS_DATA = List.of(
            new Patient(1001, "Ben Johnson", LocalDate.of(1957, 4, 19)),
            new Patient(1003, "Charles Babbage", LocalDate.of(1957, 4, 18)),
            new Patient(1002, "Anna Smith", LocalDate.of(1958, 5, 14))
    );

    public static List<Patient> findAll() {
        return PATIENTS_DATA;
    }
}
